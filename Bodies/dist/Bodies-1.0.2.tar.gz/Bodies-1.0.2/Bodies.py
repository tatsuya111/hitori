#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys

import jp.ac.kyoto_su.cse.mi.Example as example

if __name__ == '__main__': sys.exit(example.main())
